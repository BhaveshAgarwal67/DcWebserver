# DcWebserver
This is a python module for discord bot makers, this module helps you in hostineg your bot on uptimer services ,as it opens a window and then all you have to do is to copy the address of the window and host it on a uptimer service 

# Using DcWebserver
To use this module after installing You have to just include `keepAlive()` after the code and before making the discord client run your bot token

# Dependecies 

This module depends on 2 other modules namely 
<br> 1 )Flask
<br>2 )Threading

Installing
----------

Install and update using `pip`_:



    $ pip install DcWebserver

# Developer 
Made By [itzQuicksilver](https://github.com/QuicksilverYT)